# 贴吧 Android 应用

这是一个功能完整的贴吧Android应用，使用Java开发，实现了帖子管理、回复互动、点赞收藏等核心功能。

## 功能特性

### 1. 帖子列表
- ✅ 显示不同版块（热门、最新、水区等）的帖子列表
- ✅ 支持多种排序方式（最新发布、最新回复）
- ✅ 列表项展示：标题、作者、发布时间、最后回复时间、浏览数、回复数、点赞数
- ✅ 标签筛选功能（科技、生活、学习、娱乐、讨论）

### 2. 帖子详情
- ✅ 完整显示帖子标题、作者、内容和发布时间
- ✅ 显示全部回复列表
- ✅ 支持楼中楼回复（二级回复）
- ✅ 显示封面图片

### 3. 发布与编辑
- ✅ 发布新帖：选择版块、输入标题和内容
- ✅ 支持添加封面图片（最多1张）
- ✅ 标签选择（最多3个）
- ✅ 内容编辑器支持粗体、斜体、添加链接等基础格式
- ✅ 编辑帖子：用户可编辑自己发布的帖子
- ✅ 删除帖子：用户可删除自己发布的帖子（带确认对话框）

### 4. 互动功能
- ✅ 回复/评论：在帖子详情页底部可直接回复帖子（主回复）
- ✅ 支持对特定楼层进行回复（二级回复/楼中楼）
- ✅ 点赞/喜欢：对帖子或回复进行点赞，并显示点赞数
- ✅ 收藏：用户可以将感兴趣的帖子加入个人收藏夹

### 5. 首页模块
- ✅ 展示所有讨论话题卡片
- ✅ 支持热度/最新排序切换
- ✅ 标签筛选（科技、生活、学习、娱乐、讨论）
- ✅ 版块切换（全部、热门、最新、水区）

## 技术架构

### 架构模式
- **MVVM架构**：Model-View-ViewModel
- **Repository模式**：统一数据访问层

### 主要技术栈
- **语言**：Java
- **UI框架**：Material Design Components
- **数据库**：Room (SQLite)
- **异步处理**：LiveData + ExecutorService
- **图片加载**：Glide
- **依赖注入**：手动依赖注入

### 项目结构

```
app/src/main/java/com/my/tieba/
├── model/                      # 数据模型
│   ├── User.java              # 用户实体
│   ├── Post.java              # 帖子实体
│   ├── Reply.java             # 回复实体
│   ├── Tag.java               # 标签实体
│   ├── Favorite.java          # 收藏实体
│   └── Like.java              # 点赞实体
│
├── database/                   # 数据库层
│   ├── TiebaDatabase.java     # Room数据库
│   └── dao/                   # 数据访问对象
│       ├── UserDao.java
│       ├── PostDao.java
│       ├── ReplyDao.java
│       ├── TagDao.java
│       ├── FavoriteDao.java
│       └── LikeDao.java
│
├── repository/                 # 仓库层
│   ├── UserRepository.java
│   ├── PostRepository.java
│   ├── ReplyRepository.java
│   ├── TagRepository.java
│   ├── FavoriteRepository.java
│   └── LikeRepository.java
│
├── viewmodel/                  # ViewModel层
│   ├── UserViewModel.java
│   ├── PostViewModel.java
│   ├── ReplyViewModel.java
│   ├── TagViewModel.java
│   └── InteractionViewModel.java
│
├── adapter/                    # RecyclerView适配器
│   ├── PostAdapter.java
│   ├── ReplyAdapter.java
│   └── SubReplyAdapter.java
│
├── utils/                      # 工具类
│   ├── TimeUtils.java         # 时间格式化
│   └── ImageUtils.java        # 图片处理
│
└── Activity/                   # Activity层
    ├── MainActivity.java       # 主页-帖子列表
    ├── PostDetailActivity.java # 帖子详情页
    ├── CreatePostActivity.java # 创建帖子页
    └── EditPostActivity.java   # 编辑帖子页
```

## 数据库设计

### 主要表结构

1. **users** - 用户表
   - id, username, avatar, email, createTime

2. **posts** - 帖子表
   - id, title, content, coverImage, authorId, authorName, board, tags
   - createTime, lastReplyTime, viewCount, replyCount, likeCount, isDeleted

3. **replies** - 回复表
   - id, postId, parentReplyId, content, authorId, authorName
   - replyToUserId, replyToUserName, floor, createTime, likeCount, isDeleted

4. **tags** - 标签表
   - id, name, color, postCount

5. **favorites** - 收藏表
   - id, userId, postId, createTime

6. **likes** - 点赞表
   - id, userId, targetId, targetType, createTime

## 核心功能实现

### 1. 楼中楼回复
- 主回复：`parentReplyId = 0`
- 二级回复：`parentReplyId = 主回复ID`
- 自动楼层编号管理

### 2. 点赞系统
- 支持对帖子和回复点赞
- 使用`targetType`区分对象类型
- 实时更新点赞数量

### 3. 收藏功能
- 用户可收藏喜欢的帖子
- 支持取消收藏
- 实时显示收藏状态

### 4. 文本格式化
- 支持粗体、斜体样式
- 支持插入链接
- 使用SpannableString实现

### 5. 图片上传
- 支持选择本地图片
- 自动压缩和保存
- 使用Glide加载显示

## 使用说明

### 环境要求
- Android Studio Arctic Fox或更高版本
- Android SDK 26及以上
- Gradle 8.0+

### 运行步骤
1. 克隆项目到本地
2. 使用Android Studio打开项目
3. 等待Gradle同步完成
4. 连接Android设备或启动模拟器
5. 点击运行按钮

### 初始数据
应用首次启动时会自动创建：
- 默认用户
- 5个预设标签（科技、生活、学习、娱乐、讨论）
- 5个示例帖子

## 权限说明
- `READ_EXTERNAL_STORAGE` - 读取外部存储（上传图片）
- `READ_MEDIA_IMAGES` - 读取媒体图片（Android 13+）

## 待优化功能
- [ ] 用户注册和登录系统
- [ ] 网络数据同步
- [ ] 图片多选上传
- [ ] 富文本编辑器
- [ ] 消息通知系统
- [ ] 用户个人中心
- [ ] 搜索功能

## 开发者
使用Java开发的完整贴吧Android应用

## 许可证
MIT License


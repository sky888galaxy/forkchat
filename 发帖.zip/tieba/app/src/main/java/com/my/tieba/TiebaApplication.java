package com.my.tieba;

import android.app.Application;

import com.my.tieba.database.TiebaDatabase;
import com.my.tieba.model.Post;
import com.my.tieba.model.Tag;
import com.my.tieba.model.User;

/**
 * Application类 - 初始化应用
 */
public class TiebaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        
        // 初始化数据库并插入示例数据
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        TiebaDatabase.databaseWriteExecutor.execute(() -> {
            TiebaDatabase db = TiebaDatabase.getDatabase(this);
            
            // 检查是否已有数据
            int userCount = db.userDao().getAllUsers().getValue() != null ? 
                    db.userDao().getAllUsers().getValue().size() : 0;
            
            if (userCount == 0) {
                // 创建默认用户
                User user = new User("默认用户", "", "user@example.com");
                long userId = db.userDao().insert(user);
                
                // 创建示例标签
                String[] tagNames = {"科技", "生活", "学习", "娱乐", "讨论"};
                String[] tagColors = {"#FF5722", "#4CAF50", "#2196F3", "#FF9800", "#9C27B0"};
                
                for (int i = 0; i < tagNames.length; i++) {
                    Tag tag = new Tag(tagNames[i], tagColors[i]);
                    db.tagDao().insert(tag);
                }
                
                // 创建示例帖子
                String[] titles = {
                    "欢迎来到贴吧!",
                    "分享一些学习心得",
                    "今天天气真好",
                    "有什么好看的电影推荐吗?",
                    "讨论一下最新的技术趋势"
                };
                
                String[] contents = {
                    "这是一个全新的贴吧应用,支持发帖、回复、点赞等功能。",
                    "最近在学习Android开发,感觉收获很多。",
                    "阳光明媚,适合出去走走。",
                    "周末想看电影,求推荐!",
                    "AI和机器学习越来越火了,大家怎么看?"
                };
                
                String[] boards = {"热门", "学习", "水区", "娱乐", "讨论"};
                String[] tags = {"科技,学习", "学习", "生活", "娱乐", "科技,讨论"};
                
                for (int i = 0; i < titles.length; i++) {
                    Post post = new Post(titles[i], contents[i], userId, "默认用户", boards[i]);
                    post.setTags(tags[i]);
                    post.setViewCount((i + 1) * 10);
                    post.setReplyCount((i + 1) * 3);
                    post.setLikeCount((i + 1) * 5);
                    db.postDao().insert(post);
                }
            }
        });
    }
}


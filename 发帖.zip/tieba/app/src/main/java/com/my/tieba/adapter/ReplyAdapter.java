package com.my.tieba.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.my.tieba.R;
import com.my.tieba.model.Reply;
import com.my.tieba.utils.ImageUtils;
import com.my.tieba.utils.TimeUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 回复列表适配器
 */
public class ReplyAdapter extends RecyclerView.Adapter<ReplyAdapter.ReplyViewHolder> {
    private Context context;
    private List<Reply> mainReplyList;
    private Map<Long, List<Reply>> subRepliesMap;
    private OnReplyActionListener listener;

    public ReplyAdapter(Context context) {
        this.context = context;
        this.mainReplyList = new ArrayList<>();
        this.subRepliesMap = new HashMap<>();
    }

    public void setReplyList(List<Reply> allReplies) {
        if (allReplies == null) return;
        
        // 分离主回复和子回复
        mainReplyList.clear();
        subRepliesMap.clear();
        
        for (Reply reply : allReplies) {
            if (reply.getParentReplyId() == 0) {
                mainReplyList.add(reply);
            } else {
                long parentId = reply.getParentReplyId();
                if (!subRepliesMap.containsKey(parentId)) {
                    subRepliesMap.put(parentId, new ArrayList<>());
                }
                subRepliesMap.get(parentId).add(reply);
            }
        }
        
        notifyDataSetChanged();
    }

    public void setOnReplyActionListener(OnReplyActionListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ReplyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_reply, parent, false);
        return new ReplyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReplyViewHolder holder, int position) {
        Reply reply = mainReplyList.get(position);
        
        holder.tvAuthor.setText(reply.getAuthorName());
        holder.tvFloor.setText(reply.getFloor() + "楼");
        holder.tvTime.setText(TimeUtils.getTimeAgo(reply.getCreateTime()));
        holder.tvContent.setText(reply.getContent());
        
        // 加载头像
        if (reply.getAuthorAvatar() != null && !reply.getAuthorAvatar().isEmpty()) {
            ImageUtils.loadCircleImage(context, reply.getAuthorAvatar(), holder.ivAvatar);
        }
        
        // 回复对象
        if (reply.getReplyToUserName() != null && !reply.getReplyToUserName().isEmpty()) {
            holder.tvReplyTo.setVisibility(View.VISIBLE);
            holder.tvReplyTo.setText("回复 @" + reply.getReplyToUserName() + ":");
        } else {
            holder.tvReplyTo.setVisibility(View.GONE);
        }
        
        // 点赞按钮
        holder.btnLike.setText("点赞 " + reply.getLikeCount());
        holder.btnLike.setOnClickListener(v -> {
            if (listener != null) {
                listener.onLikeClick(reply);
            }
        });
        
        // 回复按钮
        holder.btnReply.setOnClickListener(v -> {
            if (listener != null) {
                listener.onReplyClick(reply);
            }
        });
        
        // 处理楼中楼
        List<Reply> subReplies = subRepliesMap.get(reply.getId());
        if (subReplies != null && !subReplies.isEmpty()) {
            holder.recyclerViewSubReplies.setVisibility(View.VISIBLE);
            SubReplyAdapter subAdapter = new SubReplyAdapter(context);
            subAdapter.setSubReplyList(subReplies);
            holder.recyclerViewSubReplies.setLayoutManager(new LinearLayoutManager(context));
            holder.recyclerViewSubReplies.setAdapter(subAdapter);
            
            subAdapter.setOnSubReplyClickListener(subReply -> {
                if (listener != null) {
                    listener.onReplyClick(subReply);
                }
            });
        } else {
            holder.recyclerViewSubReplies.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mainReplyList.size();
    }

    static class ReplyViewHolder extends RecyclerView.ViewHolder {
        TextView tvAuthor, tvFloor, tvTime, tvContent, tvReplyTo;
        ImageView ivAvatar;
        Button btnLike, btnReply;
        RecyclerView recyclerViewSubReplies;

        public ReplyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAuthor = itemView.findViewById(R.id.tvAuthor);
            tvFloor = itemView.findViewById(R.id.tvFloor);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvContent = itemView.findViewById(R.id.tvContent);
            tvReplyTo = itemView.findViewById(R.id.tvReplyTo);
            ivAvatar = itemView.findViewById(R.id.ivAvatar);
            btnLike = itemView.findViewById(R.id.btnLike);
            btnReply = itemView.findViewById(R.id.btnReply);
            recyclerViewSubReplies = itemView.findViewById(R.id.recyclerViewSubReplies);
        }
    }

    public interface OnReplyActionListener {
        void onLikeClick(Reply reply);
        void onReplyClick(Reply reply);
    }
}


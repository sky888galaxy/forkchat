package com.my.tieba.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.my.tieba.database.dao.FavoriteDao;
import com.my.tieba.database.dao.LikeDao;
import com.my.tieba.database.dao.PostDao;
import com.my.tieba.database.dao.ReplyDao;
import com.my.tieba.database.dao.TagDao;
import com.my.tieba.database.dao.UserDao;
import com.my.tieba.model.Favorite;
import com.my.tieba.model.Like;
import com.my.tieba.model.Post;
import com.my.tieba.model.Reply;
import com.my.tieba.model.Tag;
import com.my.tieba.model.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Room数据库
 */
@Database(entities = {User.class, Post.class, Reply.class, Tag.class, Favorite.class, Like.class},
        version = 1, exportSchema = false)
public abstract class TiebaDatabase extends RoomDatabase {

    public abstract UserDao userDao();
    public abstract PostDao postDao();
    public abstract ReplyDao replyDao();
    public abstract TagDao tagDao();
    public abstract FavoriteDao favoriteDao();
    public abstract LikeDao likeDao();

    private static volatile TiebaDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static TiebaDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (TiebaDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    TiebaDatabase.class, "tieba_database")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}


package com.my.tieba.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.my.tieba.database.TiebaDatabase;
import com.my.tieba.database.dao.UserDao;
import com.my.tieba.model.User;

import java.util.List;

/**
 * 用户仓库
 */
public class UserRepository {
    private UserDao userDao;

    public UserRepository(Application application) {
        TiebaDatabase database = TiebaDatabase.getDatabase(application);
        userDao = database.userDao();
    }

    public LiveData<User> getUserById(long userId) {
        return userDao.getUserById(userId);
    }

    public void insertUser(User user, OnUserInsertedListener listener) {
        TiebaDatabase.databaseWriteExecutor.execute(() -> {
            long id = userDao.insert(user);
            if (listener != null) {
                listener.onUserInserted(id);
            }
        });
    }

    public void updateUser(User user) {
        TiebaDatabase.databaseWriteExecutor.execute(() -> {
            userDao.update(user);
        });
    }

    public LiveData<List<User>> getAllUsers() {
        return userDao.getAllUsers();
    }

    public interface OnUserInsertedListener {
        void onUserInserted(long userId);
    }
}


package com.my.tieba.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.my.tieba.model.User;
import com.my.tieba.repository.UserRepository;

/**
 * 用户ViewModel
 */
public class UserViewModel extends AndroidViewModel {
    private UserRepository repository;
    private MutableLiveData<Long> currentUserId = new MutableLiveData<>(1L); // 默认用户ID为1

    public UserViewModel(@NonNull Application application) {
        super(application);
        repository = new UserRepository(application);
    }

    public LiveData<User> getUserById(long userId) {
        return repository.getUserById(userId);
    }

    public void insertUser(User user, UserRepository.OnUserInsertedListener listener) {
        repository.insertUser(user, listener);
    }

    public void updateUser(User user) {
        repository.updateUser(user);
    }

    public MutableLiveData<Long> getCurrentUserId() {
        return currentUserId;
    }

    public void setCurrentUserId(long userId) {
        currentUserId.setValue(userId);
    }

    public long getCurrentUserIdValue() {
        Long userId = currentUserId.getValue();
        return userId != null ? userId : 1L;
    }
}

